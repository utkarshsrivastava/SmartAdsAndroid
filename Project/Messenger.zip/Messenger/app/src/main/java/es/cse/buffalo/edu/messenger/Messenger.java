package es.cse.buffalo.edu.messenger;

import android.content.Context;
import android.graphics.Color;
import android.net.wifi.WifiManager;
import android.os.AsyncTask;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.text.util.Linkify;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import org.json.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.math.BigInteger;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.UnknownHostException;
import java.nio.ByteOrder;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Formatter;
import java.util.List;


public class Messenger extends ActionBarActivity {

    private TextView wifiTextBox;
    private TextView editTextBox;
    private TextView messageView;
    private Button button;
    static final String TAG = Messenger.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_messenger);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_messenger, menu);
        String wifiAddress = wifiIpAddress(getApplicationContext());
        wifiTextBox =(TextView) findViewById(R.id.clientWifiTxt);
        editTextBox = (TextView) findViewById(R.id.editText);
        button = (Button) findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String message = editTextBox.getText().toString();
                if(!message.trim().isEmpty()) {
                    new ClientTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, message);
                }
            }
        });
        messageView = (TextView) findViewById(R.id.textView);
        messageView.setText("My wifi address is : "+wifiAddress+"\n");
        try {
            ServerSocket serverSocket = new ServerSocket(10000);
            new ServerTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, serverSocket);
        } catch (IOException e) {
            Log.e(TAG, "Can't create a ServerSocket");
        }
        return true;
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    protected String wifiIpAddress(Context context) {
        WifiManager wifiManager = (WifiManager) context.getSystemService(WIFI_SERVICE);
        int ipAddress = wifiManager.getConnectionInfo().getIpAddress();

        // Convert little-endian to big-endianif needed
        if (ByteOrder.nativeOrder().equals(ByteOrder.LITTLE_ENDIAN)) {
            ipAddress = Integer.reverseBytes(ipAddress);
        }

        byte[] ipByteArray = BigInteger.valueOf(ipAddress).toByteArray();

        String ipAddressString;
        try {
            ipAddressString = InetAddress.getByAddress(ipByteArray).getHostAddress();
        } catch (UnknownHostException ex) {
            Log.e("WIFIIP", "Unable to get host address.");
            ipAddressString = null;
        }

        return ipAddressString;
    }


    private class ServerTask extends AsyncTask<ServerSocket, String, Void> {

        @Override
        protected Void doInBackground(ServerSocket... sockets) {
            ServerSocket serverSocket = sockets[0];

            Socket clientSocket = null;
            try {
                while(true) {
                    clientSocket = serverSocket.accept();
                    InputStream clientStream = clientSocket.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(clientStream));
                    String data = reader.readLine();
                    publishProgress(data);
                    new AdTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, data);
                    clientStream.close();
                    clientSocket.close();
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        protected void onProgressUpdate(String...strings) {
            /*
             * The following code displays what is received in doInBackground().
             */
            String strReceived = strings[0].trim();
            TextView remoteTextView = (TextView) findViewById(R.id.textView);
            remoteTextView.append(strReceived + "\t\n");
            return;
        }
    }

    private class AdTask extends AsyncTask<String, String, Void> {

        protected Void doInBackground(String... params) {
            sendAdQuery(params[0]);
            return null;
        }

        protected void onProgressUpdate(String...strings) {
            /*
             * The following code displays what is received in doInBackground().
             */
            showAd(strings[0]);
            return;
        }


        /*
        AdInfo": {
          "key": "Value"
            }
         */
        public void sendAdQuery(String message) {
            String combinedIP = wifiTextBox.getText().toString().trim();
            String[] ipAddrs = combinedIP.split(";");
            String serverIpAddr = ipAddrs[1];
            HttpClient client = new DefaultHttpClient();
            HttpContext localContext = new BasicHttpContext();
            String hashedWords="";
            try {
                hashedWords = genHashRequestForKeywords(message);
            }catch (Exception e){
            }
            HttpGet httpGet = new HttpGet("http://"+serverIpAddr+"/Middleware/queryads/"+ hashedWords);
            String text = null;
            try {
                HttpResponse response = client.execute(httpGet, localContext);
                HttpEntity entity = response.getEntity();
                InputStream stream = entity.getContent();
                BufferedReader reader = new BufferedReader(new InputStreamReader(stream));
                text = reader.readLine();
            //Receive JSON response
                String json = text;
                JSONObject obj = new JSONObject(json);
                String link = obj.getString("link");
                String content = obj.getString("content");
                String adValue = link+"\n" + content;
                if (adValue != null)
                    publishProgress(adValue);
            } catch (Exception e) {
                System.out.println(text);
                e.printStackTrace();
            }
        }
    }

    protected void showAd(String ad)
    {
        TextView t =(TextView) findViewById(R.id.textView1);
        if(t == null)
            Log.d("NULL","TextBox is NULL");
//        Log.d("Ad","Ad is "+ad);
        String[] values = ad.split("\n");
//        Log.d("Ad","length "+values.length);
//        Log.d("Ad","val 0 "+values[0]);
//        Log.d("Ad","val 1 "+values[1]);

//        Log.d("Link"," link = "+str_text);

        if(values.length ==2) {
            String str_text = "<a href=\""+values[0]+"\">"+values[1]+"</a>";
            if (t != null) {
                t.setText(Html.fromHtml(str_text));
                t.setMovementMethod(LinkMovementMethod.getInstance());
                t.setTextColor(Color.BLUE);
            }
        }
        else {
            Log.d("Ad","Incomplete Ad");
        }
    }

    private class ClientTask extends AsyncTask<String, String, Void>{
        public void sendMessage(String message) {
            try {
                String combinedIP =wifiTextBox.getText().toString().trim();
                String[] ipAddrs = combinedIP.split(";");
                String ipAddress = ipAddrs[0];
                new AdTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR, message);
                Socket socket = new Socket(InetAddress.getByName(ipAddress),10000);
                String msgToSend = message+"\n";
                BufferedWriter writer = new BufferedWriter(new PrintWriter(socket.getOutputStream()));
                writer.write(msgToSend);
                writer.close();
                socket.close();
            } catch (UnknownHostException e) {
                Log.e(TAG, "ClientTask UnknownHostException");
            } catch (IOException e) {
                Log.e(TAG, "ClientTask socket IOException");
            }
        }



        @Override
        protected Void doInBackground(String... params) {
            sendMessage(params[0]);
            publishProgress(params[0]);
            return null;
        }

        protected void onProgressUpdate(String...strings) {
            /*
             * The following code displays what is received in doInBackground().
             */
            messageView.append(strings[0]+"\t\n");
            editTextBox.setText("");
            return;
        }
    }

    private String genHashRequestForKeywords(String input) throws NoSuchAlgorithmException {
        StringBuilder builder = new StringBuilder();
        String[] keywords = input.split(" ");
        for(String keyword:keywords){
            builder.append(genHash(keyword)+",");
        }
        return builder.substring(0,builder.length()-1);
    }

    private String genHash(String input) throws NoSuchAlgorithmException {
        MessageDigest sha1 = MessageDigest.getInstance("MD5");
        byte[] sha1Hash = sha1.digest(input.getBytes());
        Formatter formatter = new Formatter();
        for (byte b : sha1Hash) {
            formatter.format("%02x", b);
        }
        return formatter.toString();
    }
}
