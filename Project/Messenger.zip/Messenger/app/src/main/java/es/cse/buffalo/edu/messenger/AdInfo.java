package es.cse.buffalo.edu.messenger;

/**
 * Created by rohit on 5/4/15.
 */
public class AdInfo {

    private String adDetails;
    private String content;
    private String link;

    public void setContent(String content) {
        this.content = content;
    }

    public String getContent() {
        return content;
    }

    public String getAdDetails() {
        return adDetails;
    }

    public void setAdDetails(String adDetails) {
        this.adDetails = adDetails;
    }

    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }

}
