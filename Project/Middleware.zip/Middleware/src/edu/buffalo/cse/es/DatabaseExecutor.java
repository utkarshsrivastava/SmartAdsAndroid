package edu.buffalo.cse.es;

import java.sql.*;
import java.util.Map;
import java.util.Set;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class DatabaseExecutor {

	private String driverName;
	private String connectionString;

	public DatabaseExecutor(String connectionString,String driverName) {
		this.connectionString=connectionString;
		this.driverName=driverName;
	}

	public Connection getConnection() throws ClassNotFoundException, SQLException{
        Class.forName(driverName);
	    return DriverManager.getConnection(connectionString);
	}

//	private Connection getConnection(String driverName,String connectionString) throws ClassNotFoundException, SQLException{
//		this.connectionString=connectionString;
//		this.driverName=driverName;
//		String sDriverName = "org.sqlite.JDBC";
//		Class.forName(sDriverName);
//		String sTempDb = "//E:/Dev/ads.db";
//		String sJdbc = "jdbc:sqlite";
//		String sDbUrl = sJdbc + ":" + sTempDb;
//		return DriverManager.getConnection(sDbUrl);
//	}


	private Connection getConnectionFromDataSource(String DATASOURCE_CONTEXT) throws ClassNotFoundException, SQLException{
		try{
		Context initialContext = new InitialContext();
	    DataSource datasource = (DataSource)initialContext.lookup(DATASOURCE_CONTEXT);
	    return datasource.getConnection();
		}catch(Exception e){
			return null;
		}
	}

	public boolean createMappingTable(){
		Connection conn =null;
		boolean success = true;
		try {
			conn =getConnection() ;
            Statement stmt = conn.createStatement();
           	String sMakeTable = "CREATE TABLE if not exists KeywordMapping (id INTEGER IDENTITY, keyword TEXT, hash TEXT)";
            stmt.executeUpdate(sMakeTable);
            stmt.close();
        } catch(Exception ignoreMe){
        	success=false;
        }
		finally {
            try { if(conn!=null) conn.close(); } catch (Exception ignore) {}
        }
		return success;
	}
	
	public boolean insertIntoMappingTable(String string,String hash){
		Connection conn =null;
		boolean success = true;
		try {
			conn =getConnection() ;
            String insertIntoKeywordMapping = "INSERT INTO KeywordMapping(keyword,hash) VALUES(?,?)";
            PreparedStatement stmt = conn.prepareStatement(insertIntoKeywordMapping);
        	stmt.setString(1, string);
        	stmt.setString(2, hash);
            stmt.execute();
            stmt.close();
		}
		catch(Exception e){
			success=false;
		} finally {
            try { conn.close(); } catch (Exception ignore) {}
        }
		return success;
	}
	
	public boolean bulkInsertIntoMappingTable(Map<String,String> map){
		Connection conn =null;
		boolean success = true;
		try {
			conn =getConnection() ;
			conn.setAutoCommit(false);
			String insertIntoKeywordMapping = "INSERT INTO KeywordMapping(keyword,hash) VALUES(?,?)";
            PreparedStatement stmt = conn.prepareStatement(insertIntoKeywordMapping);
            int count=1;
            int totalrecords=0;
			Set<String> values = map.keySet();
            for(String temp : values){
            	int i=1;
            	stmt.setString(i++, temp );
				stmt.setString(i++, map.get(temp));
				stmt.addBatch();
            	if(count==50000){
            		totalrecords+=count;
            		stmt.executeBatch();
					stmt.clearBatch();
//            		System.out.println("Records Left : "+ (map.size() -totalrecords)) ;
            		count=0;
            	}
            	count++;
            }
            if(count!=0)
            	stmt.executeBatch();
            stmt.close();
            conn.commit();
		}
		catch(Exception e){
			try {
				e.printStackTrace();
				conn.rollback();
			} catch (SQLException ignore) {
			}
			success=false;
		} finally {
            try { conn.close(); } catch (Exception ignore) {}
        }
		return success;
	}
}
