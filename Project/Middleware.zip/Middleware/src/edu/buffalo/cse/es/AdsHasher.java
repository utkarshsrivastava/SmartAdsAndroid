package edu.buffalo.cse.es;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Formatter;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 * Created by rohit on 5/2/15.
 */
public class AdsHasher {

    public static  void main(String args[]) throws Exception{
        new AdsHasher().hashAds();
        new AdsHasher().hashContentAds();
    }

    private String genHash(String input) throws NoSuchAlgorithmException {
        MessageDigest sha1 = MessageDigest.getInstance("SHA-1");
        byte[] sha1Hash = sha1.digest(input.getBytes());
        Formatter formatter = new Formatter();
        for (byte b : sha1Hash) {
            formatter.format("%02x", b);
        }
        return formatter.toString();
    }
    
    public void hashContentAds() throws  Exception{
        File file = new File("/home/rohit/solr-4.10.2/example/solr/ads/content.csv");
        Set<String> treeSet= new TreeSet<>();
        BufferedReader reader = new BufferedReader(new FileReader(file));
        String value=null;
        while((value=reader.readLine())!=null){
            treeSet.add(value.toLowerCase());
        }
        TreeMap<String,String> processedWords = new TreeMap<>();
        Iterator<String> iterator = treeSet.iterator();
        MessageDigest digest = MessageDigest.getInstance("MD5");
        while (iterator.hasNext()) {
            String topic = iterator.next();
            String[] keywords = topic.split("\\s+");
            for (int i=0;i<keywords.length;i++){
                byte[] md5Calc = digest.digest(keywords[i].getBytes());
                if(!processedWords.containsKey(keywords[i])) {
                    Formatter formatter = new Formatter();
                    for (byte b : md5Calc) {
                        formatter.format("%02x", b);
                    }
                    processedWords.put(keywords[i], formatter.toString());
                }
            }
        }
        String jdbcUrl="jdbc:sqlite://home/rohit/ads.db";
        DatabaseExecutor db = new DatabaseExecutor(jdbcUrl,"org.sqlite.JDBC");
        db.createMappingTable();
        db.bulkInsertIntoMappingTable(processedWords);
    }

    public void hashAds() throws  Exception{
        File file = new File("/home/rohit/solr-4.10.2/example/solr/ads/full-data.csv");
        Set<String> treeSet= new TreeSet<>();
        BufferedReader reader = new BufferedReader(new FileReader(file));
        String value=null;
        while((value=reader.readLine())!=null){
            String columns[] = value.split(",");
            if(columns.length<2)
                continue;
            String content = columns[2].trim();
            treeSet.add(content.toLowerCase());
        }
        TreeMap<String,String> processedWords = new TreeMap<>();
        Iterator<String> iterator = treeSet.iterator();
        MessageDigest digest = MessageDigest.getInstance("MD5");
        while (iterator.hasNext()) {
            String topic = iterator.next();
            String[] keywords = topic.split("\\s+");
            for (int i=0;i<keywords.length;i++){
                byte[] md5Calc = digest.digest(keywords[i].getBytes());
                if(!processedWords.containsKey(keywords[i])) {
                    Formatter formatter = new Formatter();
                    for (byte b : md5Calc) {
                        formatter.format("%02x", b);
                    }
                    processedWords.put(keywords[i], formatter.toString());
                }
            }
        }
        String jdbcUrl="jdbc:sqlite://home/rohit/ads.db";
        DatabaseExecutor db = new DatabaseExecutor(jdbcUrl,"org.sqlite.JDBC");
        db.createMappingTable();
        db.bulkInsertIntoMappingTable(processedWords);
    }
}
