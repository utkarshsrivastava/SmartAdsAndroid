package edu.buffalo.cse.es;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;

import org.apache.solr.client.solrj.SolrQuery;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.client.solrj.impl.HttpSolrServer;
import org.apache.solr.client.solrj.response.QueryResponse;
import org.apache.solr.common.SolrDocument;
import org.apache.solr.common.SolrDocumentList;

import com.google.gson.Gson;

@Path("/queryads")
public class SolrConn {
	private static String delimiter = "~~";
	public String reverseMap(List<String> keywords) {
		StringBuilder queryForSolr = new StringBuilder();
		String selectQuery = "SELECT distinct keyword from KeywordMapping where hash = ?";
		try {
			Connection connection = getConnection();
			PreparedStatement statement = connection.prepareStatement(selectQuery);
			Iterator<String> it = keywords.iterator();
			while(it.hasNext()) {
				String hashedKeyword = it.next();
				statement.setString(1, hashedKeyword);
				ResultSet resultSet = statement.executeQuery();
				while(resultSet.next()) {
					String keyword = resultSet.getString("keyword");
					queryForSolr.append(keyword + " ");
				}
			}
			statement.clearParameters();			
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
		return queryForSolr.toString();
	}
	
	public Connection getConnection() throws ClassNotFoundException, SQLException{
        Class.forName("org.sqlite.JDBC");
        String jdbcUrl="jdbc:sqlite://home/rohit/ads.db";
	    return DriverManager.getConnection(jdbcUrl);
	}
	
	@GET
	@Path("/multiple")
	@Produces(javax.ws.rs.core.MediaType.APPLICATION_JSON) 	
	public String getAdsFromSolr(@QueryParam("parameter") List<String> keywords) {
		//Give solr address
		String solrAddr = "http://localhost:8983/solr/ads";
		HttpSolrServer httpSolrServer = new HttpSolrServer(solrAddr);
		SolrQuery solrQuery = new SolrQuery();
		String query = reverseMap(keywords);
		solrQuery.setQuery(query);
		QueryResponse response = null;
		Ad ads = new Ad();
			try {
				response = httpSolrServer.query(solrQuery);
				SolrDocumentList solrDocumentList = response.getResults();
				if(solrDocumentList.size() > 0) {
					SolrDocument solrDocument = solrDocumentList.get(0);
					//get all fields
					ads.setAdDetails(solrDocument.getFieldValue("title").toString());
					ads.setLink(solrDocument.getFieldValue("SiteLink").toString());
					ads.setContent(solrDocument.getFieldValue("content").toString());
					
//					String adresponse = solrDocument.getFieldValue("SiteLink").toString() + 
//							delimiter + solrDocument.getFieldValue("title").toString();
//					
//					Response.status(200).en
				}else{
					ads.setAdDetails("");
					ads.setLink("");
					ads.setContent("");
				}
			} catch (SolrServerException e) {
				e.printStackTrace();
			}
			return new Gson().toJson(ads);
	}
	
	@GET
	@Path("/{parameter}")
	@Produces(javax.ws.rs.core.MediaType.APPLICATION_JSON) 	
	public String getAdsFromSolr(@PathParam("parameter") String query) {
		//Give solr address
		List<String> keywords = Arrays.asList(query.split(","));
		String solrAddr = "http://localhost:8983/solr/ads";
		HttpSolrServer httpSolrServer = new HttpSolrServer(solrAddr);
		SolrQuery solrQuery = new SolrQuery();
		String filteredQuery = reverseMap(keywords);
		solrQuery.setQuery(filteredQuery);
		QueryResponse response = null;
		Ad ads = new Ad();
			try {
				response = httpSolrServer.query(solrQuery);
				SolrDocumentList solrDocumentList = response.getResults();
				if(solrDocumentList.size() > 0) {
					SolrDocument solrDocument = solrDocumentList.get(0);
					//get all fields
					ads.setAdDetails(solrDocument.getFieldValue("title").toString());
					ads.setLink(solrDocument.getFieldValue("SiteLink").toString());
					ads.setContent(solrDocument.getFieldValue("content").toString());
					
//					String adresponse = solrDocument.getFieldValue("SiteLink").toString() + 
//							delimiter + solrDocument.getFieldValue("title").toString();
//					
//					Response.status(200).en
				}else{
					ads.setAdDetails("");
					ads.setLink("");
					ads.setContent("");
				}
			} catch (SolrServerException e) {
				e.printStackTrace();
			}
			return new Gson().toJson(ads);
	}
}
